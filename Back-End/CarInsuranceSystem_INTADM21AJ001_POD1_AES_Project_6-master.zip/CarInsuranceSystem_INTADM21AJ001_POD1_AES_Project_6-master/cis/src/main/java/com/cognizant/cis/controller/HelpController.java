package com.cognizant.cis.controller;

import org.springframework.web.bind.annotation.RestController;


import com.cognizant.cis.model.Help;
import com.cognizant.cis.service.HelpService.adminHelpService;
import com.cognizant.cis.service.HelpService.helpService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;



@RestController
@CrossOrigin("http://localhost:4200")
public class HelpController {
	@Autowired
	helpService service;
	@Autowired
	adminHelpService aHelpService;
	
	@PostMapping("/seekhelp")
	public String seekHelp(@RequestBody Help help) {
	return service.saveHelp(help);
		}
	
	
	@GetMapping("/viewhelp")
	public List<Help> getAllHelp(){
       return aHelpService.getAllHelp();
        
}
@PostMapping("/checkstatus")
	
	public String checkStatus(@RequestBody Help help) {
	return service.getStatus(help);
	
}

@PostMapping("/updatestatus")

public String updateStatus(@RequestBody Help help) {
return aHelpService.updateStatus(help);

}

}
