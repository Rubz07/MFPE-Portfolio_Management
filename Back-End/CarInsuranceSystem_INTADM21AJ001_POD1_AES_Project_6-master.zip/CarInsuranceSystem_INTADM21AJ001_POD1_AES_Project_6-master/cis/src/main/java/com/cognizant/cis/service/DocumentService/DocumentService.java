package com.cognizant.cis.service.DocumentService;

import java.util.List;

import com.cognizant.cis.model.Document;

public interface DocumentService {
      public List<Document>  getAllDocument();
      public String saveMyDocument(Document document);
      public String deleteMydocument(long document_id);
      public String status(Document document);
      public String updateStatus(Document document);
      public String updateStatusApp(Document document);
}
