package com.cognizant.cis.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToOne;

@Entity
public class Document {
    @Id  
    @GeneratedValue(strategy = GenerationType.AUTO)
	private long did;
    private String aadhar_no;
    private String car_registration_no;
    private String driving_license_no;
    private String bank_name;
    private String account_no;
    private String bank_ifsc;
    private int status;
    
    @OneToOne
    @JoinColumn(name="user_id")
    private Users user;
    public Document() {}
	

	

	public Document(long did, String aadhar_no, String car_registration_no, String driving_license_no, String bank_name,
			String account_no, String bank_ifsc, int status, Users user) {
		super();
		this.did = did;
		this.aadhar_no = aadhar_no;
		this.car_registration_no = car_registration_no;
		this.driving_license_no = driving_license_no;
		this.bank_name = bank_name;
		this.account_no = account_no;
		this.bank_ifsc = bank_ifsc;
		this.status = status;
		this.user = user;
	}




	public long getDid() {
		return did;
	}


	public void setDid(long did) {
		this.did = did;
	}


	public String getAadhar_no() {
		return aadhar_no;
	}

	public void setAadhar_no(String aadhar_no) {
		this.aadhar_no = aadhar_no;
	}

	public String getCar_registration_no() {
		return car_registration_no;
	}

	public void setCar_registration_no(String car_registration_no) {
		this.car_registration_no = car_registration_no;
	}

	public String getDriving_license_no() {
		return driving_license_no;
	}

	public void setDriving_license_no(String driving_license_no) {
		this.driving_license_no = driving_license_no;
	}

	public String getBank_name() {
		return bank_name;
	}

	public void setBank_name(String bank_name) {
		this.bank_name = bank_name;
	}

	public String getAccount_no() {
		return account_no;
	}

	public void setAccount_no(String account_no) {
		this.account_no = account_no;
	}

	public String getBank_ifsc() {
		return bank_ifsc;
	}

	public void setBank_ifsc(String bank_ifsc) {
		this.bank_ifsc = bank_ifsc;
	}

	public Users getUser() {
		return user;
	}

	

	public void setUser(Users user) {
		this.user = user;
	}
	
	public int getStatus() {
		return status;
	}


	public void setStatus(int status) {
		this.status = status;
	}


	@Override
	public String toString() {
		return "Document [did=" + did + ", aadhar_no=" + aadhar_no + ", car_registration_no=" + car_registration_no
				+ ", driving_license_no=" + driving_license_no + ", bank_name=" + bank_name + ", account_no="
				+ account_no + ", bank_ifsc=" + bank_ifsc + ", status=" + status + ", user=" + user + "]";
	}

	
    
}
