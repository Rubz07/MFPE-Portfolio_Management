package com.cognizant.cis.model;

public interface MappingCarType {
	Long getCount();
	String getCar_type();


}
