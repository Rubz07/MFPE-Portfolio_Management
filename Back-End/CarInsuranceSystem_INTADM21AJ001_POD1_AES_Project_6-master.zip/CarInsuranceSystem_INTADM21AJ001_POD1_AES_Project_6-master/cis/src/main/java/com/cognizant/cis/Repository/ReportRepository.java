package com.cognizant.cis.Repository;
import java.util.*;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.cis.model.BuyInsurance;
import com.cognizant.cis.model.MappingCarType;
import com.cognizant.cis.model.MappingInsuranceType;
@Repository
public interface ReportRepository extends JpaRepository<BuyInsurance, Long>{
	@Query(value = "SELECT COUNT(b.insurance_id) as count, b.insurancetype FROM buy_insurance b GROUP BY b.insurancetype", nativeQuery = true)
	public List<MappingInsuranceType> findBuyInsuranceTypeCount();
	
	@Query(value = "SELECT COUNT(a.insurance_id) as count, a.car_type FROM buy_insurance a GROUP BY a.car_type", nativeQuery = true)
	public List<MappingCarType> findByCartypeCount();
	
	@Query(value = "SELECT *from buy_insurance where MONTH(purchase_date) = MONTH(now());", nativeQuery = true)
		public List<BuyInsurance> findByMonth();
}
