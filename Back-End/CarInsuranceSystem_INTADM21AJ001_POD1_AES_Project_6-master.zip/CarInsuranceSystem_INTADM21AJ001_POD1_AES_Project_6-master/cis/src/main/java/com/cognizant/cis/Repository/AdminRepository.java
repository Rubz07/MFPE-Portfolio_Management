package com.cognizant.cis.Repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.cis.model.Admin;



public interface AdminRepository extends JpaRepository<Admin, Long> {
	
	  Admin findByEmail(String email);
}
