 package com.cognizant.cis.service.HelpService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;


import com.cognizant.cis.model.Help;
import com.cognizant.cis.Repository.*;
@Service
public class adminHelpService implements IadminHelpService {
	 @Autowired
    private HelpRepository hRepo;
    
    
    
	 public adminHelpService() {
			super();
			// TODO Auto-generated constructor stub
		}



	@Override
	public List<Help> getAllHelp() {
		// TODO Auto-generated method stub
		List<Help> help = hRepo.findAll();
		return help;
	}
	@Override
	public String  updateStatus(Help help) {
		help = hRepo.findByPid(help.getPid());
		help.setStatus(1);
		hRepo.save(help);
		return "Updated";
	}

}
