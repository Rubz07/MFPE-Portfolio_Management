package com.cognizant.cis.service.UsersService;

import java.util.List;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.cis.Repository.UserRepository;
import com.cognizant.cis.model.Login;
import com.cognizant.cis.model.Users;


@Service
public class UserService implements IUserService 
{
	@Autowired
	private UserRepository repo;
	
	//@Autowired
	//Users user;
	
	
	
	public UserService() {}

	public UserService(UserRepository repo) {
		super();
		this.repo = repo;
	}
	
	
	@Override
	public List<Users> getAllUser(){
		List<Users> user = repo.findAll();
		return user;
	}
    @Override
	public String saveMyUser(Users user) {
		
		repo.save(user);
		return "User Saved";
		
	}
	/*public UserService(LoginRepository lrepo) {
		super();
		this.lrepo = lrepo;
	}
	public List<Login> getAllLogin(){
		List<Login> login = lrepo.findAll();
		return login;
	}

	public void saveMyLogin(Login login) {
		// TODO Auto-generated method stub
		lrepo.save(login);
		
	}*/

	@Override
	public String login(Login login) {
		// TODO Auto-generated method stub
		Users lis = repo.findByEmail(login.getEmail());
		if(lis!=null && lis.getPassword().equals(login.getPassword()))
		{
				return "You Are Succesfully Logged In as "/*lis.getRole()*/;
		}
		else
		{
			return "Invalid UserName or Password";
		}
	}
}

