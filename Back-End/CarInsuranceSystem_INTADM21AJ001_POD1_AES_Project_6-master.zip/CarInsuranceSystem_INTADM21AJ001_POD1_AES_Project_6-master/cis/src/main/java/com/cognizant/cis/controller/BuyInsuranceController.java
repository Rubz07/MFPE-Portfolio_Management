package com.cognizant.cis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.cis.model.BuyInsurance;
import com.cognizant.cis.service.BuyInsuranceService.BuyInsuranceService;

@RestController
@CrossOrigin("http://localhost:4200")
public class BuyInsuranceController {
	
	
	
	@Autowired
	BuyInsuranceService bservice;
	
	@PostMapping("/buyinsurance")
	public String buyInsurance(@RequestBody BuyInsurance buyinsurance) {
		return bservice.buyInsurance(buyinsurance);
	}
	
	@GetMapping("/viewcustomers")
	public List<BuyInsurance> viewCustomers(){
		return bservice.viewCustomers();
	
	}

}
