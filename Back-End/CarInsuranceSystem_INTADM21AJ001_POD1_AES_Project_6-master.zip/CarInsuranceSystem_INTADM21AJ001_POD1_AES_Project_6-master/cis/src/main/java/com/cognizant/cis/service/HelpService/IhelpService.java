package com.cognizant.cis.service.HelpService;



import com.cognizant.cis.model.Help;

public interface IhelpService {
	public String saveHelp(Help help);
	public String getStatus(Help help);
}
