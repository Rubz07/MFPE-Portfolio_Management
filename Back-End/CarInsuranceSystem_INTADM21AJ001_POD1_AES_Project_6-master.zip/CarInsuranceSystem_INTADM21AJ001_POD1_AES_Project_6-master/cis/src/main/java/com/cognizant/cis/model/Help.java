package com.cognizant.cis.model;

import javax.persistence.*;
import org.hibernate.annotations.DynamicUpdate;


	@Entity
	@Table
	@DynamicUpdate
	public class Help {

		@Id
		@GeneratedValue(strategy = GenerationType.IDENTITY)
		private long pid;
		private String name;
		private String email;
		private String topic;
		private String help_Details;
	    private int status;
		
		public int getStatus() {
			return status;
		}
		public void setStatus(int status) {
			this.status = status;
		}
		public Help() {
			super();
			// TODO Auto-generated constructor stub
		}
		
		public Help(long pid, String name, String email, String topic, String help_Details, int status) {
			super();
			this.pid = pid;
			this.name = name;
			this.email = email;
			this.topic = topic;
			this.help_Details = help_Details;
			this.status = status;
		}
		public long getPid() {
			return pid;
		}
		public void setPid(long pid) {
			this.pid = pid;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public String getTopic() {
			return topic;
		}
		public void setTopic(String topic) {
			this.topic = topic;
		}
		public String getHelp_Details() {
			return help_Details;
		}
		public void setHelp_Details(String help_Details) {
			this.help_Details = help_Details;
		}
		

		
		
	}



