package com.cognizant.cis.model;

public interface MappingInsuranceType {
	Long getCount();
	String getInsuranceType();

}
