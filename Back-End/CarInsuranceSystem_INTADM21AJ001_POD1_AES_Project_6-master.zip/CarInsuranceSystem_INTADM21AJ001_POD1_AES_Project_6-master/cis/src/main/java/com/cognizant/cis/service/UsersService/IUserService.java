package com.cognizant.cis.service.UsersService;

import java.util.List;



import com.cognizant.cis.model.Login;
import com.cognizant.cis.model.Users;




public interface IUserService {
	public List<Users> getAllUser();
	public String saveMyUser(Users user);
	public String login(Login login);

}
