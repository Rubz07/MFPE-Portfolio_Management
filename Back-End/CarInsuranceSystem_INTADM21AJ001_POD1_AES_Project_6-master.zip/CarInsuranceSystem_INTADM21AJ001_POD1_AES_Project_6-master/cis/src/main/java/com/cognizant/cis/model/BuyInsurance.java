package com.cognizant.cis.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

import org.springframework.stereotype.Component;

import java.time.LocalDate;

@Component
@Entity
public class BuyInsurance {
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 @Column(name="insurance_id")
	 private long id;
	 @Column(name ="car_type")
	 private String car_type;
	 private String insurancetype;
	 private String duration_in_months;
	 private String car_number;
	 private LocalDate expiryDate;
	 private int total_amount;
	 
	
	 
	public BuyInsurance(long id, String car_type, String insurancetype, String duration_in_months, String car_number,
			LocalDate expiryDate, LocalDate purchaseDate, int total_amount) {
		super();
		this.id = id;
		this.car_type = car_type;
		this.insurancetype = insurancetype;
		this.duration_in_months = duration_in_months;
		this.car_number = car_number;
		this.expiryDate = expiryDate;
		this.purchaseDate = purchaseDate;
		this.total_amount = total_amount;
	}


	public BuyInsurance() {
		super();
		// TODO Auto-generated constructor stub
	}


	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getCar_type() {
		return car_type;
	}
	public void setCar_type(String car_type) {
		this.car_type = car_type;
	}
	public String getInsurancetype() {
		return insurancetype;
	}
	public void setInsurancetype(String insurancetype) {
		this.insurancetype = insurancetype;
	}
	public String getDuration_in_months() {
		return duration_in_months;
	}
	public void setDuration_in_months(String duration_in_months) {
		this.duration_in_months = duration_in_months;
	}
	public String getCar_number() {
		return car_number;
	}
	public void setCar_number(String car_number) {
		this.car_number = car_number;
	}
	
	 public LocalDate getExpiryDate() {
			return expiryDate;
		}


		public void setExpiryDate(LocalDate expiryDate) {
			this.expiryDate = expiryDate;
		}


		LocalDate purchaseDate=LocalDate.now();
		 
		 
		 public LocalDate getPurchaseDate() {
			return purchaseDate;
		}


		public void setPurchaseDate() {
			this.purchaseDate = purchaseDate;
		}
		
		


	public int getTotal_amount() {
			return total_amount;
		}


		public void setTotal_amount(int total_amount) {
			this.total_amount = total_amount;
		}


		@Override
		public String toString() {
			return "BuyInsurance [id=" + id + ", car_type=" + car_type + ", insurancetype=" + insurancetype
					+ ", duration_in_months=" + duration_in_months + ", car_number=" + car_number + ", expiryDate="
					+ expiryDate + ", total_amount=" + total_amount + ", purchaseDate=" + purchaseDate + "]";
		}



	

}