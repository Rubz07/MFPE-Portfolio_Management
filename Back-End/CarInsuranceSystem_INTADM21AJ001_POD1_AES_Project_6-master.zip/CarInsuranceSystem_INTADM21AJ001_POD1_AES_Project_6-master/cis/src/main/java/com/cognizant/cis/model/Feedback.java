package com.cognizant.cis.model;


import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Feedback {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long Id;
	private String feedback_details;
	private int rating;
	
	//@OneToOne
	//private CUser cuser;
	
	public Feedback(long Id, String feedback_details, int rating) {
		super();
		this.Id = Id;
		this.feedback_details = feedback_details;
		this.rating = rating;
	}
	
	@Override
	public String toString() {
		return "feedback_details [Id=" + Id + ", feedback_details=" + feedback_details + ", rating=" + rating + "]";
	}

	public Feedback() {}
	
	public long getId() {
		return Id;
	}
	public void setfeedback_detailsId(long Id) {
		this.Id = Id;
	}
	public String getFeedback_details() {
		return feedback_details;
	}
	public void setFeedback_details(String feedback_details) {
		this.feedback_details = feedback_details;
	}
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	
	
	
	

}

