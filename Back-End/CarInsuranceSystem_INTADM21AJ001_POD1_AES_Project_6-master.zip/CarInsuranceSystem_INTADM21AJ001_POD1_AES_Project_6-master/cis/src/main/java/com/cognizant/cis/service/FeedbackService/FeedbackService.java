package com.cognizant.cis.service.FeedbackService;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.cis.Repository.FeedbackRepository;
import com.cognizant.cis.model.Feedback;

@Service
public class FeedbackService implements IFeedbackService {
	
	@Autowired
	private FeedbackRepository frepo;
	
	
	
	public FeedbackService() {
		super();
		// TODO Auto-generated constructor stub
	}

    public FeedbackService(FeedbackRepository frepo) {
		super();
		this.frepo = frepo;
	}



	@Override
	public String saveMyFeedback(Feedback feedback) {
		frepo.save(feedback);
		return "Feedback is saved successfully!!. your feedback id is "+feedback.getId();
	}
	
	/*

	@Override
	public String updateFeedback(Feedback feedback){
         frepo.saveAndFlush(feedback);
         return "Feedback updated";
   }
   */
	
	public String updateFeedback(Feedback feedback,Long id) {
		Feedback f=frepo.getById(id);
		f.setFeedback_details(feedback.getFeedback_details());
		f.setRating(feedback.getRating());
		frepo.saveAndFlush(f);
		return "Feedback updated";
		
	}
	
	
	
	public String deleteFeedback(Long id) {
		 frepo.deleteById(id);
		 return "Feedback deleted";
	}
	

	}
	