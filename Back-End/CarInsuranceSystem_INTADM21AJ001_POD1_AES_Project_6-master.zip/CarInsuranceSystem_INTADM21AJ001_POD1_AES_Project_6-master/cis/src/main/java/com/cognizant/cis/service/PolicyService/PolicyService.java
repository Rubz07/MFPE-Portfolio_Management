package com.cognizant.cis.service.PolicyService;

import com.cognizant.cis.model.Policy;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.cis.Repository.PolicyRepository;

@Service
public class PolicyService{
	@Autowired
	PolicyRepository prepo;
	
	public String registerPolicy(Policy policy) {
		prepo.save(policy);
		return "Policy Added";
		
	}
	
	public List<Policy> getPolicy(){
		return (List<Policy>) prepo.findAll();		 
	}
	
	
	public void deletePolicy(long id) {
		prepo.deleteById(id);
	}
	
	public Policy updatePolicy(Policy policy) {
		long id = policy.getId();
		Policy p= prepo.findById(id).get();
		p.setInsurancetype(policy.getInsurancetype());
		p.setDuration_in_months(policy.getDuration_in_months());
		p.setTotal_amount(policy.getTotal_amount());
		return prepo.save(p);
	}
	
	
	
//	@Override
//	public String addMyPolicy(Policy policy) {
//		prepo.saveAndFlush(policy);
//		return "Policy Added";
//	}
//	
//	
//	@Override
//	public String saveMyPolicy(Policy policy) {
//		prepo.save(policy);
//		return "Policy details Saved";
//		
//}
//	@Override
//	public List<Policy> getAllPolicy() {
//		List<Policy> policy = prepo.findAll();
//		return policy;
//		
//	}
//	
//	@Override
//    public Optional<Policy>findById(Long id) {
//
//        return prepo.findById(id);
//    }
}