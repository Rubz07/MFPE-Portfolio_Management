package com.cognizant.cis.service.AdminService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.cis.Repository.AdminRepository;
import com.cognizant.cis.model.Admin;
import com.cognizant.cis.model.AdminLogin;
import com.cognizant.cis.model.Login;
import com.cognizant.cis.model.Users;

@Service
public class AdminServiceImpl implements AdminService {
    @Autowired
	AdminRepository arepo;
	@Override
	public String addMyAdmin(Admin admin) {
		// TODO Auto-generated method stub
		 arepo.saveAndFlush(admin);
		 return "Admin Saved";
		
	
	}
	@Override
	public String ALogin(AdminLogin adminlogin) {
		// TODO Auto-generated method stub
		Admin a = arepo.findByEmail(adminlogin.getEmail());
		if(a!=null && a.getpassword().equals(adminlogin.getpassword()))
		
		{
				return "You Are Succesfully Logged In as Admin";
		}
		else
		{
			return "Invalid UserName or Password";
		}
	}

}
