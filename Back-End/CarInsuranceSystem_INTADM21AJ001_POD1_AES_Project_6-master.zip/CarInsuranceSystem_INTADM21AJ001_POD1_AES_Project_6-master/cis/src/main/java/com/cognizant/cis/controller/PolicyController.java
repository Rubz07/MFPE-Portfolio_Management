package com.cognizant.cis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;


import com.cognizant.cis.model.*;
import com.cognizant.cis.service.PolicyService.PolicyService;



@RestController
@CrossOrigin(origins="http://localhost:4200")
public class PolicyController {
	
	@Autowired
	PolicyService pservice;
	
	
	
	@PostMapping("/registerpolicy")
	public String registerPolicy(@RequestBody Policy policy) {
		return pservice.registerPolicy(policy);
		
	}
	
	@GetMapping("/getpolicy")
	public List<Policy> getPolicy() {
		return pservice.getPolicy();
	}
	
	@DeleteMapping("/deletePolicy")
	public void deletePolicy(@RequestParam long id) {
		pservice.deletePolicy(id);
	}
	
	@PutMapping("/updatePolicy")
	public Policy updatePolicy(@RequestBody Policy policy) {
		return  pservice.updatePolicy(policy);
	}
	//@GetMapping(value = "/{id}")
	//public Optional<Policy> getPolicy(@PathVariable Long id) {
	  //  return pservice.findById(id);
	//}
	
//	@Autowired
//	private PolicyRepository policyRepository;
//	
//	@DeleteMapping(path = { "/{id}" })
//	public Policy deletePolicy(@PathVariable long id) {
//		Policy p=policyRepository.getById(id);
//		policyRepository.delete(p);
//		return p;
//	}
//	@PutMapping(path={"/{id}"})
//	public Policy saveOrUpdatePolicy(@RequestBody Policy policy) {
//		policyRepository.save(policy);
//		return policy;
//		
//	}
}	