package com.cognizant.cis.controller;

import java.util.List;

import javax.transaction.Transactional;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.cognizant.cis.model.Admin;
import com.cognizant.cis.model.AdminLogin;
import com.cognizant.cis.model.Login;
import com.cognizant.cis.model.Users;
import com.cognizant.cis.service.AdminService.AdminServiceImpl;
import com.cognizant.cis.service.UsersService.UserService;





@org.springframework.web.bind.annotation.RestController
@CrossOrigin("http://localhost:4200")
public class SignUpController {
	
	@Autowired
    UserService service;
	
	@Autowired
	AdminServiceImpl aservice;
	
	@PostMapping("/savecustomer")
	@Transactional
	public String postUser(@RequestBody Users user) {
		return service.saveMyUser(user);
		
	}
	@GetMapping("/getcustomer")
	public List<Users> getUser(){
       return service.getAllUser();
}
	
	@PostMapping("/customerlogin")
	public String login(@RequestBody Login login)
	{
		return service.login(login);
	}
	
	@PostMapping("/saveadmin")
	public String addAdmin(@RequestBody Admin admin ) {
		return aservice.addMyAdmin(admin);
	}
	@PostMapping("/adminlogin")
	public String adminLogin(@RequestBody AdminLogin adminlogin) {
		return aservice.ALogin(adminlogin);
	}
	
}

