package com.cognizant.cis.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.cis.model.Users;
@Repository
public interface UserRepository  extends JpaRepository<Users, Long>{
            Users findByEmail(String email);
            
}