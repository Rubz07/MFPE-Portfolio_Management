package com.cognizant.cis.service.HelpService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.cis.Repository.HelpRepository;
import com.cognizant.cis.model.Help;
@Service
public class helpService implements IhelpService {
       
	
	
	@Autowired
	private HelpRepository hRepo;
	public helpService() {
		
	}
	
	public helpService(HelpRepository hRepo) {
		super();
		this.hRepo = hRepo;
	}

	@Override
	public String saveHelp(Help help) {
		// TODO Auto-generated method stub
		hRepo.save(help);
		return "Your reference Number is  " +help.getPid();
	
	}
	@Override
	public String getStatus(Help help) {
    	help = hRepo.findByPid(help.getPid());
    	if(help.getStatus()==0){
    		return "Your Status is still Open";
    	}
      
    	else {
    	return "Status Closed";
    	
    	
    	
    }
 
    }


}
