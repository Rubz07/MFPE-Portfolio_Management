package com.cognizant.cis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.cis.Repository.ReportRepository;
import com.cognizant.cis.model.BuyInsurance;
import com.cognizant.cis.model.MappingCarType;
import com.cognizant.cis.model.MappingInsuranceType;
import com.cognizant.cis.service.ReportService.ReportService;

@RestController
@CrossOrigin("http://localhost:4200")
public class ReportController {
	
	
	
	@Autowired
	ReportService rRepo;
	
	
	@GetMapping("/viewreport")
	public List<BuyInsurance> getReport(){
	       return rRepo.getMonthly();
	        
	}
	@GetMapping("/iviewreport")
	public List<MappingInsuranceType> getIReport(){
	       return rRepo.getInsuranceType();
	        
	}
	@GetMapping("/vviewreport")
	public List<MappingCarType> getVReport(){
	       return rRepo.getCarType();
	}
		
	}
	
	


