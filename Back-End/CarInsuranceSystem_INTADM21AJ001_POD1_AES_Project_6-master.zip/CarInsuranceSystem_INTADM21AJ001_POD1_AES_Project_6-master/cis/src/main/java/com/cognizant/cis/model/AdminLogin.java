package com.cognizant.cis.model;

public class AdminLogin {
	private String email;
	private String password;
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getpassword() {
		return password;
	}
	public void setpassword(String password) {
		this.password = password;
	}
	public AdminLogin(String email, String password) {
		super();
		this.email = email;
		this.password = password;
	}
	public AdminLogin() {}
	@Override
	public String toString() {
		return "AdminLogin [email=" + email + ", password=" + password + "]";
	}

}
