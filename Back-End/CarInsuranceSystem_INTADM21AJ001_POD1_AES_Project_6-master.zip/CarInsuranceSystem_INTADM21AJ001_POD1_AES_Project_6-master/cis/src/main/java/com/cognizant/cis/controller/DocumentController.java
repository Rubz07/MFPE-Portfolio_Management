package com.cognizant.cis.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.cognizant.cis.model.Document;
import com.cognizant.cis.service.DocumentService.DocumentserviceImpl;
@RestController
@CrossOrigin("http://localhost:4200")
public class DocumentController {
      
	@Autowired
	DocumentserviceImpl dservice;
	
	@GetMapping("/getdocument")
	public List<Document> printInsurance(){
		return dservice.getAllDocument();
	}
	@PostMapping("/savedocument")
	public String saveDocument(@RequestBody Document document){
		 dservice.saveMyDocument(document);
		 return "Your Document Id is "+document.getDid();
	}
	@DeleteMapping("/{did}")
	public String deleteDocument(@PathVariable long document_id){
		 dservice.deleteMydocument(document_id);
		 return "Document delete";
	}
	@PostMapping("/checkdocstatus")
	public String checkStatus(@RequestBody Document document) {
		return "Status: "+dservice.status(document);
		
	}
	@PostMapping("/updatedocstatus")
	public String updateMyStatus(@RequestBody Document document) {
		return "Status :"+dservice.updateStatus(document);
	}
	@PostMapping("/updatedocstatusapp")
	public String updateAppStatus(@RequestBody Document document) {
		return "Status :"+dservice.updateStatusApp(document);
	}
	
}
