package com.cognizant.cis.service.BuyInsuranceService;

import java.time.LocalDate;
import java.util.List;

import com.cognizant.cis.model.BuyInsurance;

public interface IBuyInsuranceService {
 
	public String buyInsurance(BuyInsurance buyinsurance);
	
	public List<BuyInsurance> viewCustomers();
	
	//public String removeCustomers(LocalDate date);
}
