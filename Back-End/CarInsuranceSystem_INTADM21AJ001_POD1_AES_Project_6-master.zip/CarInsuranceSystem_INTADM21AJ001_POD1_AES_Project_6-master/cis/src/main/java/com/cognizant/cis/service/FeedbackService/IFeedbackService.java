package com.cognizant.cis.service.FeedbackService;



import com.cognizant.cis.model.Feedback;

public interface IFeedbackService {
	
	public String saveMyFeedback(Feedback feedback);
	
	//public String updateFeedback(Feedback feedback);
	
	public String deleteFeedback(Long id);
	 
	public String updateFeedback(Feedback feedback,Long id);
	
}
