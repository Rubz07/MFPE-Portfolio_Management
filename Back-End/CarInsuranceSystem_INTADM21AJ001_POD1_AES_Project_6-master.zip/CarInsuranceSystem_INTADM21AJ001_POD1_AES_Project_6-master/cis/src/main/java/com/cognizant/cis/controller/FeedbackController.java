package com.cognizant.cis.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.cognizant.cis.model.Feedback;
import com.cognizant.cis.service.FeedbackService.FeedbackService;







@RestController
@CrossOrigin("http://localhost:4200")
public class FeedbackController {
	
	@Autowired
	FeedbackService fservice;
	
	@PostMapping("/savefeedback")
	public String saveMyFeedback(@RequestBody Feedback feedback) {
		return fservice.saveMyFeedback(feedback);
		}
	
	
   /*
	@PutMapping("/updatefeedback")
	public String updateFeedback(@RequestBody Feedback feedback) {
		return fservice.updateFeedback(feedback);
	}
	*/
	
	
	@PutMapping("/updatefeedback/{id}")
	public String updatefeedback(@RequestBody Feedback feedback ,@PathVariable Long id) {
	     return fservice.updateFeedback(feedback,id);
	 }
	
	@DeleteMapping("/deletefeedback/{id}")
	public String deleteFeedback(@PathVariable Long id) {
	     return fservice.deleteFeedback(id);
	}
	

}
