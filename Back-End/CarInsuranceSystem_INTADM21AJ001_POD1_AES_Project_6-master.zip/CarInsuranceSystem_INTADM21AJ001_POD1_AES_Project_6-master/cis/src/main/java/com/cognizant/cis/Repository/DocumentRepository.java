package com.cognizant.cis.Repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.cis.model.Document;

@Repository
public interface DocumentRepository extends JpaRepository<Document, Long> {
           Document findByDid(long did);
}
