package com.cognizant.cis.service.ReportService;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;
import com.cognizant.cis.model.*;
import com.cognizant.cis.Repository.*;

@Service
@Component
public class ReportService {
	
public ReportService() {
		super();
		// TODO Auto-generated constructor stub
	}






public ReportService(ReportRepository rRepo, BuyInsurance b) {
	super();
	this.rRepo = rRepo;
	this.b = b;
}






@Autowired
ReportRepository rRepo;
@Autowired
BuyInsurance b;




public List<BuyInsurance> getMonthly() {
	// TODO Auto-generated method stub
	List<BuyInsurance> buyinsurance = rRepo.findByMonth();
	return buyinsurance;
}

public List<MappingInsuranceType> getInsuranceType(){
	List<MappingInsuranceType> bb = rRepo.findBuyInsuranceTypeCount();
	return bb;
}

public List<MappingCarType> getCarType(){
	List<MappingCarType> bb = rRepo.findByCartypeCount();
	return bb;
}

}
