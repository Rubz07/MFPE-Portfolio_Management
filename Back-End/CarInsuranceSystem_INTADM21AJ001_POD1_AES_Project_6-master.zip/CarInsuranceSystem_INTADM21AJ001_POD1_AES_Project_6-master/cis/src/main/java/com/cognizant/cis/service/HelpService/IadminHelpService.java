package com.cognizant.cis.service.HelpService;

import java.util.List;

import com.cognizant.cis.model.Help;

public interface IadminHelpService {
	public List<Help> getAllHelp();
	public String  updateStatus(Help help);
}
