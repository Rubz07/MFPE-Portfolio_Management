package com.cognizant.cis.service.BuyInsuranceService;

import java.time.LocalDate;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.cis.Repository.BuyInsuranceRepository;
import com.cognizant.cis.Repository.PolicyRepository;
import com.cognizant.cis.model.BuyInsurance;
import com.cognizant.cis.model.Policy;

@Service
public class BuyInsuranceService implements IBuyInsuranceService {
	
	@Autowired
	BuyInsuranceRepository repo;
	
	@Autowired
	PolicyRepository prepo;
	
	/*
	@Override
	public String buyInsurance(BuyInsurance buyinsurance) {
		repo.save(buyinsurance);
		return "Thanks for buying Insurance, your insurance id is "+buyinsurance.getId();
		
	}
	*/
	
	
	@Override
	public String buyInsurance(BuyInsurance buyinsurance) {
		List<Policy> pis=prepo.findByInsurancetype(buyinsurance.getInsurancetype());
		for(int i=0;i<pis.size();i++) {
		   Policy p=pis.get(i);
		   if(p.getDuration_in_months().equals(buyinsurance.getDuration_in_months())){
			  Long d= Long.parseLong(buyinsurance.getDuration_in_months());
			  
			  buyinsurance.setExpiryDate(buyinsurance.getPurchaseDate().plusMonths(d)) ;
			  buyinsurance.setTotal_amount(p.getTotal_amount());
			  repo.save(buyinsurance);
			return "Thanks for buying insurance, total amount for your policy is "+p.getTotal_amount() + " , expiry date is "+buyinsurance.getPurchaseDate().plusMonths(d) +" and  insurance id is "+buyinsurance.getId();
			
			}
		}
		
			return "No policy available";
			
		}
	
	
	@Override
	public List<BuyInsurance> viewCustomers(){
		return repo.findAll();
	}
	
	/*
	@Override
	public String removeCustomers(LocalDate date) {
		List<BuyInsurance> l= repo.findByExpiryDate(date);
		for(int i=0;i<l.size();i++) {
			BuyInsurance b=l.get(i);
			repo.delete(b);
		}
		
		return "Customers removed";
	
		
	}
	*/
	
	

}