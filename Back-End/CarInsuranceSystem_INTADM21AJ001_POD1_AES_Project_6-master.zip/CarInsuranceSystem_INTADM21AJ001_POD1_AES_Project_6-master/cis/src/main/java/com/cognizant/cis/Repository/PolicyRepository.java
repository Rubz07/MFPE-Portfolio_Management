package com.cognizant.cis.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.cognizant.cis.model.Policy;

@Repository
public interface PolicyRepository extends JpaRepository<Policy,Long> {
    List<Policy> findByInsurancetype(String insurancetype);
}