package com.cognizant.cis.Repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.cognizant.cis.model.BuyInsurance;
import com.cognizant.cis.model.Help;

@Repository

public interface HelpRepository  extends JpaRepository<Help, Long>{
	
	Help findByPid(long pid );
	
	
            
            }

