package com.cognizant.cis.service.DocumentService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cognizant.cis.Repository.DocumentRepository;
import com.cognizant.cis.model.Document;

@Service
public class DocumentserviceImpl implements DocumentService {
	
	@Autowired
	DocumentRepository drepo;
	

	@Override
	public List<Document> getAllDocument() {
		// TODO Auto-generated method stub
		return drepo.findAll();
	}

	@Override
	public String saveMyDocument(Document document) {
		// TODO Auto-generated method stub
		drepo.saveAndFlush(document);
		return "Document saved";
	}

	@Override
	public String deleteMydocument(long did) {
		// TODO Auto-generated method stub
		drepo.deleteById(did);
		return "Document delete";
	}

	@Override
	public String status(Document document) {
		// TODO Auto-generated method stub
		document = drepo.findByDid(document.getDid());
		if(document.getStatus()==0) {
		return "Verification is Pending";
	}
		else if(document.getStatus()==1) {
			return "Verification is rejected";
		}
		else {
			return "Verification is Approved";
		}

}

	@Override
	public String updateStatus(Document document) {
		// TODO Auto-generated method stub
		document = drepo.findByDid(document.getDid());
		document.setStatus(1);
		drepo.saveAndFlush(document);
				
		return "Verification is rejected";
	}

	@Override
	public String updateStatusApp(Document document) {
		// TODO Auto-generated method stub
		document = drepo.findByDid(document.getDid());
		document.setStatus(2);
		drepo.saveAndFlush(document);
		return "Verification is Approved";
	}
}
