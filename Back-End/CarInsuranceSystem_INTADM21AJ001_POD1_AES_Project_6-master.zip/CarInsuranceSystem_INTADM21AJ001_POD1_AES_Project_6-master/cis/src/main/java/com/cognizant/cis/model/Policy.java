package com.cognizant.cis.model;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Policy {
	
	 @Id
	 @GeneratedValue(strategy = GenerationType.IDENTITY)
	 private long id;
	 private String insurancetype;
	 private String duration_in_months;
	 private int totalAmount;
	 
	 
	public Policy(long id, String insurancetype, String duration_in_months, int total_amount) {
		super();
		this.id = id;
		this.insurancetype = insurancetype;
		this.duration_in_months = duration_in_months;
		this.totalAmount = total_amount;
	}
	public Policy() {
		super();
		// TODO Auto-generated constructor stub
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getInsurancetype() {
		return insurancetype;
	}
	public void setInsurancetype(String insurancetype) {
		this.insurancetype = insurancetype;
	}
	public String getDuration_in_months() {
		return duration_in_months;
	}
	public void setDuration_in_months(String duration_in_months) {
		this.duration_in_months = duration_in_months;
	}
	public int getTotal_amount() {
		return totalAmount;
	}
	public void setTotal_amount(int total_amount) {
		this.totalAmount = total_amount;
	}
	 
	 
	 
	 
	 
	
	
	

}
