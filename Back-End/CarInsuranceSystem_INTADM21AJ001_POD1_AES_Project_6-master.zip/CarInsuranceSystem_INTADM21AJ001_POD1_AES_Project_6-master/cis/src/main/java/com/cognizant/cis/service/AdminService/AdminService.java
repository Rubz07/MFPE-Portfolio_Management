package com.cognizant.cis.service.AdminService;

import com.cognizant.cis.model.Admin;
import com.cognizant.cis.model.AdminLogin;

public interface AdminService {
        public String addMyAdmin(Admin admin);
        public String ALogin(AdminLogin adminlogin);
}
