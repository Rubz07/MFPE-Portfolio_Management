package com.cognizant.cis;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CisApplicationTests {

	@Test
	void contextLoads() {
	}

}
